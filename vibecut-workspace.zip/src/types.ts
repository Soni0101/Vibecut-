/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TimelineClip {
  id: string;
  type: 'video' | 'audio' | 'voiceover' | 'text';
  title: string;
  start: number; // Start time in timeline (seconds)
  duration: number; // Duration of clip (seconds)
  volume?: number; // 0 to 100
  speed?: number; // speed ramping multiplier (e.g. 1.0, 2.0, 0.5)
  effect?: string; // filter/effect applied
  color?: string; // tailwind color class
  textStyle?: {
    fontFamily: string;
    fontSize: number;
    color: string;
    animation: string;
  };
  thumbnail?: string; // visual symbol for video/audio clips
}

export interface TimelineTrack {
  id: string;
  name: string;
  type: 'video' | 'audio' | 'voiceover' | 'text';
  clips: TimelineClip[];
}

export interface ExportConfig {
  resolution: '720p' | '1080p' | '4K';
  fps: 30 | 60;
  aspectRatio: '9:16' | '16:9' | '1:1';
  bitrate: 'standard' | 'high';
}

export interface AdStatus {
  bannerVisible: boolean;
  premiumProActive: boolean;
}

export interface CodeFile {
  name: string;
  path: string;
  language: 'dart' | 'cpp' | 'typescript' | 'yaml' | 'objective-cpp';
  code: string;
}
