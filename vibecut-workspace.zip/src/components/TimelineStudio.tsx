/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Scissors, 
  Trash2, 
  Code, 
  Sliders, 
  Music, 
  Mic, 
  Sparkles 
} from 'lucide-react';
import { TimelineTrack, TimelineClip } from '../types';

interface TimelineStudioProps {
  tracks: TimelineTrack[];
  currentTime: number;
  setCurrentTime: (time: number) => void;
  selectedClip: TimelineClip | null;
  setSelectedClip: (clip: TimelineClip | null) => void;
  zoomFactor: number;
  setZoomFactor: (zoom: number) => void;
  maxDuration: number;
  onSplit: () => void;
  onDelete: () => void;
  onUpdateClipOffset: (field: 'start' | 'duration', value: number) => void;
  onApplySpeedPreset: (curve: string) => void;
  onApplyVisualFilter: (fx: string) => void;
  speedCurve: string;
  isRecordingVoiceover: boolean;
  startRecordingVoiceover: () => void;
  stopRecordingVoiceover: () => void;
  aiPromptTopic: string;
  setAiPromptTopic: (topic: string) => void;
  isGeneratingAISubtitles: boolean;
  handleAISubtitleGeneration: () => void;
}

export default function TimelineStudio({
  tracks,
  currentTime,
  setCurrentTime,
  selectedClip,
  setSelectedClip,
  zoomFactor,
  setZoomFactor,
  maxDuration,
  onSplit,
  onDelete,
  onUpdateClipOffset,
  onApplySpeedPreset,
  onApplyVisualFilter,
  speedCurve,
  isRecordingVoiceover,
  startRecordingVoiceover,
  stopRecordingVoiceover,
  aiPromptTopic,
  setAiPromptTopic,
  isGeneratingAISubtitles,
  handleAISubtitleGeneration
}: TimelineStudioProps) {

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 shadow-xl flex flex-col gap-4">
      {/* TIMELINE OVERVIEW HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-rose-500" /> Multi-Layer Interactive Timeline
          </h2>
          <p className="text-xs text-slate-400">Click and select clips to split, apply AI speed ramping curves, or cinematic filters.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Zoom Scale:</span>
          <input 
            type="range" 
            min="8" 
            max="20" 
            value={zoomFactor} 
            onChange={(e) => setZoomFactor(parseInt(e.target.value))}
            className="w-24 h-1 bg-slate-800 rounded-lg appearance-auto accent-rose-500"
          />
        </div>
      </div>

      {/* AI AUTO SUBTITLE STUDIO PANEL Powered by Gemini */}
      <div className="bg-slate-950 rounded-xl p-4 border border-indigo-950/65 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-extrabold tracking-wide text-indigo-400 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" /> AI AUTO-SUBTITLE STUDIO
          </span>
          <span className="text-[10px] px-2 py-0.5 bg-indigo-500/10 text-indigo-300 rounded font-mono">Gemini-3.5-flash</span>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <select 
            value={aiPromptTopic}
            onChange={(e) => setAiPromptTopic(e.target.value)}
            className="flex-1 bg-slate-900 border border-slate-850 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-indigo-500"
          >
            <option value="Unboxing a premium smart foldable smartphone">Preset: Unboxing a premium foldable smartphone 📱</option>
            <option value="Tokyo cityscape cyber travel vlog and drift racing">Preset: Tokyo cityscape cyber travel vlog ✈️</option>
            <option value="Quick 60fps high-speed burger receipt culinary short">Preset: 60fps burger receipt culinary short 🍔</option>
          </select>

          <button
            onClick={handleAISubtitleGeneration}
            disabled={isGeneratingAISubtitles}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white font-bold rounded-lg px-4 py-2 text-xs flex items-center gap-1.5 transition-all shadow"
          >
            {isGeneratingAISubtitles ? (
              <>
                <div className="w-3 h-3 border-2 border-t-transparent border-indigo-300 animate-spin rounded-full" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-amber-300" /> Auto-Captions
              </>
            )}
          </button>
        </div>
        <p className="text-[10px] text-zinc-500">
          ⚡ Sends script details to the Node Express server. If no API keys are present, the backend falls back to realistic simulations gracefully.
        </p>
      </div>

      {/* TIMELINE VISUAL TRACK AREA */}
      <div className="bg-slate-950 rounded-xl border border-slate-800 p-2 overflow-x-auto select-none" id="timeline_stages">
        <div className="min-w-[420px]" style={{ width: `${maxDuration * zoomFactor + 160}px` }}>
          
          {/* TIMELINE TIME TICKS */}
          <div className="flex items-center h-8 border-b border-slate-800 relative mb-2">
            <div className="w-32 flex-shrink-0 text-[10px] text-zinc-500 font-mono font-bold uppercase pl-2">
              Time Markers
            </div>
            
            <div className="flex-1 relative h-full">
              {Array.from({ length: maxDuration + 1 }).map((_, idx) => (
                <div 
                  key={idx} 
                  onClick={() => setCurrentTime(idx)}
                  className="absolute top-0 bottom-0 flex flex-col justify-between cursor-pointer group"
                  style={{ left: `${idx * zoomFactor}px` }}
                >
                  <div className="w-[1px] h-3 bg-slate-700 group-hover:bg-rose-500 transition-colors" />
                  <span className="text-[9px] text-zinc-600 font-mono select-none -translate-x-1/2 group-hover:text-rose-400 block pb-1">
                    {idx}s
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* TRACKS LIST */}
          <div className="flex flex-col gap-2 relative">
            {/* PLAYHEAD RED SCRUB LINE RUNNING ON TIME */}
            <div 
              className="absolute top-0 bottom-0 w-[2.5px] bg-rose-500 z-10 pointer-events-none shadow-[0_0_8px_#F43F5E]"
              style={{ left: `${128 + (currentTime * zoomFactor)}px` }} // 128px tracking sidebar offset
            >
              <div className="absolute top-0 w-3.5 h-3.5 bg-rose-500 rounded-full -translate-x-1/2 -translate-y-1/2 select-none border border-white" />
            </div>

            {tracks.map((track) => (
              <div key={track.id} className="flex items-center min-h-[50px] relative bg-slate-900/40 rounded-lg border border-slate-900/60 py-1 px-1">
                {/* Left Track Column controls */}
                <div className="w-32 flex-shrink-0 flex items-center justify-between pr-3 pl-2 border-r border-slate-800">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[10px] font-bold text-slate-300 font-display flex items-center gap-1">
                      {track.type === 'text' && <Code className="w-3 h-3 text-indigo-400" />}
                      {track.type === 'video' && <Sliders className="w-3 h-3 text-rose-400" />}
                      {track.type === 'audio' && <Music className="w-3 h-3 text-emerald-400" />}
                      {track.type === 'voiceover' && <Mic className="w-3 h-3 text-amber-500 animate-pulse" />}
                      {track.name}
                    </span>
                    <span className="text-[8px] font-mono uppercase text-zinc-600">{track.type} Track</span>
                  </div>
                  {track.type === 'voiceover' && (
                    <button 
                      onClick={isRecordingVoiceover ? stopRecordingVoiceover : startRecordingVoiceover}
                      className={`p-1 rounded-full transition-all ${
                        isRecordingVoiceover 
                          ? 'bg-rose-600 animate-pulse text-white ring-2 ring-rose-500/30' 
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-400'
                      }`}
                      title={isRecordingVoiceover ? "Stop Microphone Session" : "Simulate Microphone Session"}
                    >
                      <Mic className="w-2.5 h-2.5" />
                    </button>
                  )}
                </div>

                {/* Right Tracks Clips Container */}
                <div className="flex-1 relative h-12 flex items-center">
                  {track.clips.length === 0 ? (
                    <div className="absolute inset-0 flex items-center justify-center text-[9px] text-zinc-700 italic">
                      Empty Track. Record voiceovers or import assets.
                    </div>
                  ) : (
                    track.clips.map((clip) => {
                      const isSelected = selectedClip?.id === clip.id;
                      return (
                        <div
                          key={clip.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedClip(clip);
                          }}
                          className={`absolute h-10 rounded-lg border p-1 px-2 flex flex-col justify-center cursor-pointer transition-all hover:bg-opacity-100 ${
                            clip.color
                          } ${
                            isSelected 
                              ? 'ring-2 ring-rose-500 scale-[1.01] border-white z-20 shadow-md' 
                              : 'border-white/10 opacity-85 hover:opacity-100'
                          }`}
                          style={{
                            left: `${clip.start * zoomFactor}px`,
                            width: `${clip.duration * zoomFactor}px`,
                          }}
                        >
                          <span className="text-[10px] font-extrabold text-white truncate leading-tight">
                            {clip.title}
                          </span>
                          <span className="text-[8px] font-mono text-white/60 flex justify-between items-center mt-0.5">
                            <span>{clip.duration.toFixed(1)}s</span>
                            {clip.speed && clip.speed !== 1 && (
                              <span className="text-amber-300 font-bold">🎯 {clip.speed}x</span>
                            )}
                            {clip.effect && clip.effect !== 'None' && (
                              <span className="text-cyan-300 font-bold truncate max-w-10">🎬 FX</span>
                            )}
                          </span>
                        </div>
                      );
                    })
                  )}
                </div>

              </div>
            ))}
          </div>

        </div>
      </div>

      {/* SEGMENT TOOLS AND ATTRIBUTES BAR */}
      <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <span className="text-xs font-bold text-slate-300">
            Timeline Segment Controls:
          </span>
          <div className="flex items-center gap-1.5 flex-wrap">
            <button 
              onClick={onSplit}
              disabled={!selectedClip}
              className="bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 disabled:text-zinc-700 px-3 py-1.5 rounded-lg text-xs font-extrabold text-rose-400 border border-slate-705 flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Scissors className="w-3.5 h-3.5" /> Split Clip
            </button>
            <button 
              onClick={onDelete}
              disabled={!selectedClip}
              className="bg-slate-800 hover:bg-rose-900/30 disabled:bg-slate-900 disabled:text-zinc-700 px-3 py-1.5 rounded-lg text-xs font-extrabold text-slate-400 border border-slate-705 flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" /> Delete Clip
            </button>
          </div>
        </div>

        {selectedClip ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Clip Shifting */}
            <div className="flex flex-col gap-3">
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-mono text-slate-400">Selected: <strong className="text-white">{selectedClip.title}</strong></span>
                <span className="text-[10px] bg-slate-850 text-slate-300 px-1.5 py-0.5 rounded uppercase font-mono">{selectedClip.type}</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-zinc-500 block mb-1">Start offset (sec)</label>
                  <input 
                    type="number" 
                    step="0.5"
                    min="0"
                    value={selectedClip.start}
                    onChange={(e) => onUpdateClipOffset('start', parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-zinc-500 block mb-1">Clip Duration (sec)</label>
                  <input 
                    type="number" 
                    step="0.5"
                    min="0.5"
                    value={selectedClip.duration}
                    onChange={(e) => onUpdateClipOffset('duration', parseFloat(e.target.value) || 0.5)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white outline-none focus:border-rose-500"
                  />
                </div>
              </div>
            </div>

            {/* Filter / Speed Curve properties */}
            <div className="flex flex-col gap-2">
              <div>
                <span className="text-xs font-bold text-slate-350 block mb-1.5">Apply Speed Ramping Curve:</span>
                <div className="grid grid-cols-4 gap-1.5">
                  {['linear', 'slow-mo', 'fast', 'hero'].map((curve) => (
                    <button
                      key={curve}
                      onClick={() => onApplySpeedPreset(curve)}
                      className={`p-1.5 rounded text-[10px] font-bold capitalize transition-all border cursor-pointer ${
                        speedCurve === curve 
                          ? 'bg-rose-500/10 border-rose-500 text-rose-300' 
                          : 'bg-slate-900 border-slate-800 text-slate-400'
                      }`}
                    >
                      {curve}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-xs font-bold text-zinc-400 block mb-1">Cinematic Filter/Effect:</span>
                <div className="flex gap-2">
                  {['None', 'Cinematic', 'Glitch'].map((fx) => (
                    <button
                      key={fx}
                      onClick={() => onApplyVisualFilter(fx)}
                      className={`flex-1 p-1 rounded text-[10px] font-bold transition-all border cursor-pointer ${
                        selectedClip.effect === fx || (fx === 'None' && !selectedClip.effect)
                          ? 'bg-cyan-500/10 border-cyan-500 text-cyan-300' 
                          : 'bg-slate-900 border-slate-800 text-slate-400'
                      }`}
                    >
                      {fx}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-4 text-xs text-zinc-500 italic">
            No track clip selected. Click any colored block in the timeline above to trim, split, delete, speed ramp, or apply filters.
          </div>
        )}
      </div>
    </div>
  );
}
