/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CodeFile } from './types';

export const codeSnippets: CodeFile[] = [
  {
    name: "Timeline Bloc (Flutter)",
    path: "lib/core/bloc/timeline_bloc.dart",
    language: "dart",
    code: `import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/models/timeline_clip.dart';
import '../../domain/models/timeline_track.dart';

// --- Events ---
abstract class TimelineEvent {}

class LoadTimeline extends TimelineEvent {}

class UpdateClipPosition extends TimelineEvent {
  final String clipId;
  final double newStart;
  final double newDuration;
  UpdateClipPosition(this.clipId, this.newStart, this.newDuration);
}

class SplitClipEvent extends TimelineEvent {
  final String clipId;
  final double splitTime;
  SplitClipEvent(this.clipId, this.splitTime);
}

class ApplyFilterEvent extends TimelineEvent {
  final String clipId;
  final String filterName;
  ApplyFilterEvent(this.clipId, this.filterName);
}

class RenderTimelineEvent extends TimelineEvent {
  final String outputResolution;
  final int fps;
  final String aspectRatio;
  RenderTimelineEvent(this.outputResolution, this.fps, this.aspectRatio);
}

// --- State ---
class TimelineState {
  final List<TimelineTrack> tracks;
  final double currentTime;
  final bool isPlaying;
  final bool isRendering;
  final double renderProgress;
  final String? error;

  TimelineState({
    required this.tracks,
    this.currentTime = 0.0,
    this.isPlaying = false,
    this.isRendering = false,
    this.renderProgress = 0.0,
    this.error,
  });

  TimelineState copyWith({
    List<TimelineTrack>? tracks,
    double? currentTime,
    bool? isPlaying,
    bool? isRendering,
    double? renderProgress,
    String? error,
  }) {
    return TimelineState(
      tracks: tracks ?? this.tracks,
      currentTime: currentTime ?? this.currentTime,
      isPlaying: isPlaying ?? this.isPlaying,
      isRendering: isRendering ?? this.isRendering,
      renderProgress: renderProgress ?? this.renderProgress,
      error: error,
    );
  }
}

// --- BLoC ---
class TimelineBloc extends Bloc<TimelineEvent, TimelineState> {
  TimelineBloc() : super(TimelineState(tracks: [])) {
    on<LoadTimeline>((event, emit) {
      // Load initial mock video/audio tracks for VibeCut Timeline
      final initialTracks = [
        TimelineTrack(id: 't_video', name: 'Video Layer', type: TrackType.video, clips: [
          TimelineClip(id: 'clip_v1', title: 'Cinematic Sunset', start: 0.0, duration: 8.0, speed: 1.0),
          TimelineClip(id: 'clip_v2', title: 'Neon Traffic', start: 8.0, duration: 12.0, speed: 1.0, effect: 'Glitch'),
        ]),
        TimelineTrack(id: 't_audio', name: 'Background Audio', type: TrackType.audio, clips: [
          TimelineClip(id: 'clip_a1', title: 'Deep Synth Pad', start: 0.5, duration: 19.5, volume: 80),
        ]),
      ];
      emit(TimelineState(tracks: initialTracks));
    });

    on<UpdateClipPosition>((event, emit) {
      final updatedTracks = state.tracks.map((track) {
        final updatedClips = track.clips.map((clip) {
          if (clip.id == event.clipId) {
            return clip.copyWith(start: event.newStart, duration: event.newDuration);
          }
          return clip;
        }).toList();
        return track.copyWith(clips: updatedClips);
      }).toList();
      emit(state.copyWith(tracks: updatedTracks));
    });

    on<SplitClipEvent>((event, emit) {
      final List<TimelineTrack> newTracks = [];
      for (var track in state.tracks) {
        final List<TimelineClip> newClips = [];
        for (var clip in track.clips) {
          if (clip.id == event.clipId && event.splitTime > clip.start && event.splitTime < (clip.start + clip.duration)) {
            final firstDuration = event.splitTime - clip.start;
            final secondDuration = clip.duration - firstDuration;
            
            newClips.add(clip.copyWith(
              id: '\${clip.id}_part1',
              title: '\${clip.title} (Part 1)',
              duration: firstDuration,
            ));
            newClips.add(clip.copyWith(
              id: '\${clip.id}_part2',
              title: '\${clip.title} (Part 2)',
              start: event.splitTime,
              duration: secondDuration,
            ));
          } else {
            newClips.add(clip);
          }
        }
        newTracks.add(track.copyWith(clips: newClips));
      }
      emit(state.copyWith(tracks: newTracks));
    });

    on<ApplyFilterEvent>((event, emit) {
      final updatedTracks = state.tracks.map((track) {
        final updatedClips = track.clips.map((clip) {
          if (clip.id == event.clipId) {
            return clip.copyWith(effect: event.filterName);
          }
          return clip;
        }).toList();
        return track.copyWith(clips: updatedClips);
      }).toList();
      emit(state.copyWith(tracks: updatedTracks));
    });
  }
}`
  },
  {
    name: "Native C++ FFmpeg Renderer",
    path: "android/app/src/main/jni/ffmpeg_renderer.cpp",
    language: "cpp",
    code: `#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>

#define LOG_TAG "VibeCut_FFmpeg"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" {
// Link with mobile-ffmpeg static libraries or system binaries
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libavfilter/avfilter.h>
}

class FFmpegVideoRenderer {
public:
    static int executeFFmpegCommand(const std::vector<std::string>& args) {
        int argc = args.size();
        std::vector<char*> argv;
        for (const auto& arg : args) {
            argv.push_back(const_cast<char*>(arg.c_str()));
        }
        argv.push_back(nullptr);

        LOGD("Executing C++ FFmpeg rendering script on phone GPU/CPU...");
        // This invokes custom FFmpeg command for stitching and filter pipelines on Android/iOS
        // Returns 0 on success.
        return 0; // Simulated native return
    }

    static std::string buildComplexFilter(bool speedRamping, bool glitchActive) {
        std::string filter = "";
        if (speedRamping) {
            // Speed ramping ffmpeg filter config: multi-stage setpts
            // e.g. setpts=0.5*PTS for first half (2x speedup), setpts=2.0*PTS for smooth slow-mo
            filter += "[0:v]setpts=SpeedRampClause*PTS[v_speed];";
        }
        if (glitchActive) {
            // Overlaying custom filter logic for real-time jitter/chromatic aberration
            filter += "[v_speed]rgbashift=rh=15:bv=-12[v_fx];";
        }
        return filter;
    }
};

extern "C" JNIEXPORT jint JNICALL
Java_com_vibecut_editor_NativeRenderer_renderVideo(
        JNIEnv* env,
        jobject /* this */,
        jobjectArray cmdArgs,
        jboolean speedRamp,
        jboolean hasGlitch) {
    
    int len = env->GetArrayLength(cmdArgs);
    std::vector<std::string> cppArgs;
    for (int i = 0; i < len; ++i) {
        auto jStr = (jstring)env->GetObjectArrayElement(cmdArgs, i);
        const char* rawString = env->GetStringUTFChars(jStr, nullptr);
        cppArgs.push_back(rawString);
        env->ReleaseStringUTFChars(jStr, rawString);
    }
    
    LOGD("JNI Call: Native C++ FFmpeg Render cycle requested with %d params", len);
    int result = FFmpegVideoRenderer::executeFFmpegCommand(cppArgs);
    return result;
}`
  },
  {
    name: "AdMob & Paywall Integration",
    path: "lib/services/ad_service.dart",
    language: "dart",
    code: `import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:flutter/foundation.dart';

class VibeCutAdService {
  static const String bannerAdIdAndroid = 'ca-app-pub-3940256099942544/6300978111';
  static const String bannerAdIdIos = 'ca-app-pub-3940256099942544/2934735716';
  
  static const String interstitialAdIdAndroid = 'ca-app-pub-3940256099942544/1033173712';
  static const String interstitialAdIdIos = 'ca-app-pub-3940256099942544/4411468910';

  BannerAd? _bannerAd;
  InterstitialAd? _interstitialAd;
  bool _isBannerLoaded = false;
  bool _isInterstitialReady = false;

  bool get isBannerLoaded => _isBannerLoaded;
  BannerAd? get bannerAd => _bannerAd;

  // Initialize Mobile Ads SDK
  Future<void> initialize() async {
    if (!kIsWeb) {
      await MobileAds.instance.initialize();
      loadBannerAd();
      loadInterstitialAd();
    }
  }

  // --- AdMob Banner Ad Configuration ---
  void loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: defaultTargetPlatform == TargetPlatform.android 
          ? bannerAdIdAndroid 
          : bannerAdIdIos,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          _isBannerLoaded = true;
          debugPrint("VibeCut Banner Ad Loaded: \${ad.adUnitId}");
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          _isBannerLoaded = false;
          debugPrint("Banner ad load failure: \${error.message}");
        },
      ),
    )..load();
  }

  // --- AdMob Export-Blocking Interstitial Ad ---
  void loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: defaultTargetPlatform == TargetPlatform.android 
          ? interstitialAdIdAndroid 
          : interstitialAdIdIos,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _isInterstitialReady = true;
          debugPrint("VibeCut Interstitial Ad loaded, waiting for render export request.");
        },
        onAdFailedToLoad: (error) {
          _isInterstitialReady = false;
          debugPrint("Interstitial compile error: \${error.message}");
        },
      ),
    );
  }

  // --- Trigger Interstitial on Video Export ---
  void triggerExportAdFlow({required VoidCallback onAdCompleted}) {
    if (_isInterstitialReady && _interstitialAd != null) {
      _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) {
          ad.dispose();
          loadInterstitialAd(); // Load next interstitial
          onAdCompleted();
        },
        onAdFailedToShowFullScreenContent: (ad, error) {
          ad.dispose();
          loadInterstitialAd();
          onAdCompleted();
        },
      );
      _interstitialAd!.show();
    } else {
      // Admob cache empty, export immediately so user is not blocked
      onAdCompleted();
    }
  }

  void dispose() {
    _bannerAd?.dispose();
    _interstitialAd?.dispose();
  }
}`
  },
  {
    name: "React Native Canvas Timeline",
    path: "src/components/TimelineStudio.tsx",
    language: "typescript",
    code: `import React, { useRef, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Animated, Dimensions } from 'react-native';

interface TimelineClip {
  id: string;
  title: string;
  start: number; // in seconds
  duration: number; // in seconds
  color: string;
}

interface TimelineStudioProps {
  clips: TimelineClip[];
  currentTime: number;
  durationLimit: number; // Max scale of timeline (e.g., 30s)
  zoomFactor: number; // pixels per second
  onScrub: (time: number) => void;
}

export const TimelineStudio: React.FC<TimelineStudioProps> = ({
  clips,
  currentTime,
  durationLimit = 30,
  zoomFactor = 15,
  onScrub,
}) => {
  const scrollViewRef = useRef<ScrollView>(null);
  const playheadAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Update playhead offset dynamically based on zoom factor
    const newPixelOffset = currentTime * zoomFactor;
    Animated.timing(playheadAnim, {
      toValue: newPixelOffset,
      duration: 100, // micro tick smoothing
      useNativeDriver: true,
    }).start();
  }, [currentTime, zoomFactor]);

  return (
    <View style={styles.container}>
      {/* Time Markers */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        ref={scrollViewRef}
        onScroll={(e) => {
          const scrollX = e.nativeEvent.contentOffset.x;
          // Sync scrolling position back with current global editor timing
        }}
        scrollEventThrottle={16}
        style={styles.tracksScroll}
      >
        <View style={[styles.timelineBody, { width: durationLimit * zoomFactor }]}>
          {/* Render markers */}
          <View style={styles.markersContainer}>
            {Array.from({ length: durationLimit }).map((_, idx) => (
              <View key={idx} style={[styles.timeMarker, { left: idx * zoomFactor }]}>
                <View style={styles.tick} />
                {idx % 5 === 0 ? <View style={styles.markerText}>{idx}s</View> : null}
              </View>
            ))}
          </View>

          {/* User clips layout block */}
          <View style={styles.trackContainer}>
            {clips.map((clip) => (
              <View
                key={clip.id}
                style={[
                  styles.clipBlock,
                  {
                    left: clip.start * zoomFactor,
                    width: clip.duration * zoomFactor,
                    backgroundColor: clip.color,
                  },
                ]}
              >
                <Animated.Text numberOfLines={1} style={styles.clipTitle}>
                  {clip.title}
                </Animated.Text>
              </View>
            ))}
          </View>
        </View>

        {/* Floating Playhead Indicator */}
        <Animated.View
          style={[
            styles.playhead,
            {
              transform: [{ translateX: playheadAnim }],
            },
          ]}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 180,
    backgroundColor: '#1E1E1E',
    borderTopWidth: 1,
    borderTopColor: '#333',
  },
  tracksScroll: {
    flex: 1,
  },
  timelineBody: {
    position: 'relative',
    height: '100%',
  },
  markersContainer: {
    height: 30,
    borderBottomWidth: 1.5,
    borderBottomColor: '#222',
  },
  timeMarker: {
    position: 'absolute',
    top: 5,
    height: 25,
    width: 20,
  },
  tick: {
    width: 1,
    height: 8,
    backgroundColor: '#777',
  },
  markerText: {
    fontSize: 9,
    color: '#888',
    marginTop: 2,
  },
  trackContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingVertical: 10,
  },
  clipBlock: {
    position: 'absolute',
    height: 48,
    borderRadius: 6,
    padding: 6,
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  clipTitle: {
    color: '#FFF',
    fontSize: 11,
    fontWeight: 'bold',
  },
  playhead: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 2.5,
    backgroundColor: '#E53E3E',
    zIndex: 10,
    shadowColor: '#E53E3E',
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
});`
  },
  {
    name: "FFmpeg Rendering Commands",
    path: "assets/ffmpeg_commands.txt",
    language: "yaml",
    code: `# VibeCut Production Native FFmpeg Configurations
# Full stitch + audio overlay + filters + speed multipliers:

[STITCH_AND_FILTERS_9_16]
ffmpeg -y -i input1.mp4 -i input2.mp4 -i background.mp3 -filter_complex \\
  "[0:v]scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1,setpts=PTS/1.0[v0]; \\
   [1:v]scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1,setpts=PTS/2.0[v1_slow]; \\
   [1:v]signalstats,glitch_rgb_aberration=distortion=12[v1_effect]; \\
   [v0][v1_effect]concat=n=2:v=1:a=0[v_stitched]; \\
   [2:a]volume=0.45[music_mix]" \\
  -map "[v_stitched]" -map "music_mix" -vcodec libx264 -preset fast -r 60 -crf 18 output_4k_9_16.mp4

[SPEED_RAMPING_SMOOTH_CURVE]
# Smooth velocity ramp filter from fast (2.0x) -> slow-mo (0.25x) -> standard (1.0x) using pts segment analysis:
ffmpeg -i clip.mp4 -vf "setpts='if(lt(N,120), 0.5*PTS, if(lt(N,240), 4.0*PTS, 1.0*PTS))'" -an output_ramped.mp4

[AUTO_SUBTITLE_COORDINATES]
# Drawtext overlays generated automatically via Speech-to-Text time structures:
ffmpeg -i source.mp4 -vf "drawtext=fontfile=/system/fonts/Roboto-Bold.ttf:text='Hello everyone!':x=(w-text_w)/2:y=h-220:fontsize=48:fontcolor=white:borderw=3:bordercolor=black:enable='between(t,1.2,3.5)',drawtext=fontfile=/system/fonts/Roboto-Bold.ttf:text='Welcome to VibeCut!':x=(w-text_w)/2:y=h-220:fontsize=48:fontcolor=white:borderw=3:bordercolor=black:enable='between(t,3.6,6.2)'" -codec:a copy finished_vlog.mp4`
  }
];
