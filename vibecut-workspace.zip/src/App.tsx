/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  Sparkles, 
  Music, 
  Mic, 
  Download, 
  Smartphone, 
  Cpu, 
  Coins, 
  Check, 
  Lock, 
  Code, 
  Layers, 
  X, 
  HelpCircle, 
  Flame, 
  Video,
  CheckCircle,
  Eye,
  AlertTriangle,
  Tv,
  BookOpen,
  ShoppingBag
} from 'lucide-react';
import { TimelineTrack, TimelineClip, ExportConfig } from './types';
import { codeSnippets } from './codeSnippets';
import TimelineStudio from './components/TimelineStudio';

export default function App() {
  // --- VibeCut App Editor States ---
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [zoomFactor, setZoomFactor] = useState<number>(14); // pixels per second
  const maxDuration = 20; // in seconds
  
  // Custom Timeline Tracks
  const [tracks, setTracks] = useState<TimelineTrack[]>([
    {
      id: 't_text',
      name: 'Subtitle / Title Layer',
      type: 'text',
      clips: [
        { id: 'sub_1', type: 'text', title: 'Welcome to VibeCut! 🎬', start: 1.0, duration: 4.5, color: 'bg-indigo-600/80 border-indigo-500' },
        { id: 'sub_2', type: 'text', title: 'Interactive Multi-Layer Timeline ✨', start: 6.5, duration: 5.0, color: 'bg-indigo-600/80 border-indigo-500' },
        { id: 'sub_3', type: 'text', title: 'AdMob & Subscriptions Configured', start: 13.0, duration: 5.5, color: 'bg-indigo-600/80 border-indigo-500' },
      ]
    },
    {
      id: 't_effect',
      name: 'AI Effect Layer',
      type: 'video',
      clips: [
        { id: 'fx_1', type: 'video', title: '🌈 Cinematic Glow Filter', start: 0.0, duration: 8.0, effect: 'Cinematic', color: 'bg-gradient-to-r from-amber-500/80 to-pink-500/80 border-amber-400' },
        { id: 'fx_2', type: 'video', title: '🔌 Glitch Jitter', start: 8.0, duration: 7.0, effect: 'Glitch', color: 'bg-gradient-to-r from-cyan-500/80 to-purple-500/80 border-cyan-400' },
      ]
    },
    {
      id: 't_video',
      name: 'Video Clip Layer',
      type: 'video',
      clips: [
        { id: 'clip_1', type: 'video', title: 'Sunset Timelapse.mp4', start: 0.0, duration: 9.0, speed: 1.0, color: 'bg-rose-500/85 border-rose-400' },
        { id: 'clip_2', type: 'video', title: 'Fast-Drive Cyberpunk.mp4', start: 9.0, duration: 11.0, speed: 1.0, color: 'bg-rose-500/85 border-rose-400' },
      ]
    },
    {
      id: 't_audio',
      name: 'Audio Mix Track',
      type: 'audio',
      clips: [
        { id: 'music_1', type: 'audio', title: 'Neon-Vibe Synthesizer Beat.mp3', start: 0.5, duration: 19.0, volume: 80, color: 'bg-emerald-600/80 border-emerald-400' }
      ]
    },
    {
      id: 't_voiceover',
      name: 'Recorded Voiceovers',
      type: 'voiceover',
      clips: []
    }
  ]);

  const [selectedClip, setSelectedClip] = useState<TimelineClip | null>(null);
  const [speedCurve, setSpeedCurve] = useState<string>('hero'); // hero, slow-mo, linear, fast
  const [selectedEffect, setSelectedEffect] = useState<string>('None');

  // AI Subtitle Generator State
  const [aiPromptTopic, setAiPromptTopic] = useState<string>('Unboxing a premium smart foldable smartphone');
  const [isGeneratingAISubtitles, setIsGeneratingAISubtitles] = useState<boolean>(false);

  // Voiceover Recording simulator
  const [isRecordingVoiceover, setIsRecordingVoiceover] = useState<boolean>(false);
  const [voiceoverTimer, setVoiceoverTimer] = useState<number>(0);

  // --- Export Panel States ---
  const [exportConfig, setExportConfig] = useState<ExportConfig>({
    resolution: '1080p',
    fps: 30,
    aspectRatio: '9:16', // default vertical format
    bitrate: 'standard'
  });
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [exportLogs, setExportLogs] = useState<string[]>([]);
  const [renderOutputUrl, setRenderOutputUrl] = useState<string | null>(null);

  // --- Hybrid Monetization States ---
  const [premiumProActive, setPremiumProActive] = useState<boolean>(false);
  const [showSubscriptionAlert, setShowSubscriptionAlert] = useState<boolean>(false);
  const [selectedProPlan, setSelectedProPlan] = useState<'weekly' | 'monthly' | 'yearly'>('monthly');
  const [activeTabCode, setActiveTabCode] = useState<string>('lib/core/bloc/timeline_bloc.dart');
  
  // AdMob Simulator (Interstitial Trigger on Export)
  const [showMockAd, setShowMockAd] = useState<boolean>(false);
  const [adTimer, setAdTimer] = useState<number>(5);

  // In-App Asset Store
  const [soundPacks, setSoundPacks] = useState([
    { id: 'pack_1', name: 'Cyberpunk Native Sound FX Bundle', costInCoins: 50, purchased: false, type: 'audio' },
    { id: 'pack_2', name: 'VHS glitch Cinematic Transition blocks', costInCoins: 80, purchased: false, type: 'effect' },
    { id: 'pack_3', name: 'Space Grotesk Display Font package', costInCoins: 120, purchased: false, type: 'text' }
  ]);
  const [userCoins, setUserCoins] = useState<number>(180);

  // Playhead scrub ticker loop
  useEffect(() => {
    let playheadInterval: any;
    if (isPlaying) {
      playheadInterval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= maxDuration) {
            setIsPlaying(false);
            return 0;
          }
          return Math.min(prev + 0.1, maxDuration);
        });
      }, 100);
    } else {
      clearInterval(playheadInterval);
    }
    return () => clearInterval(playheadInterval);
  }, [isPlaying]);

  // Voiceover timer ticker
  useEffect(() => {
    let recInterval: any;
    if (isRecordingVoiceover) {
      recInterval = setInterval(() => {
        setVoiceoverTimer(prev => prev + 1);
      }, 1000);
    }
    return () => {
      clearInterval(recInterval);
    };
  }, [isRecordingVoiceover]);

  // Handle auto-subtitle extraction via backend node server
  const handleAISubtitleGeneration = async () => {
    setIsGeneratingAISubtitles(true);
    try {
      const response = await fetch('/api/generate-subtitles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: aiPromptTopic,
          durationLimit: maxDuration
        })
      });
      const data = await response.json();
      if (data.success && data.subtitles) {
        // Map resulting captions to new Subtitle track state
        const generatedClips: TimelineClip[] = data.subtitles.map((sub: any, idx: number) => ({
          id: `ai_sub_${Date.now()}_${idx}`,
          type: 'text',
          title: sub.text,
          start: Math.max(0, sub.start),
          duration: Math.max(1, sub.end - sub.start),
          color: 'bg-indigo-600/90 border-amber-400 border border-dashed text-amber-200'
        }));

        setTracks(prev => prev.map(track => {
          if (track.type === 'text') {
            return {
              ...track,
              clips: [...track.clips, ...generatedClips].sort((a,b) => a.start - b.start)
            };
          }
          return track;
        }));
      }
    } catch (e) {
      console.error("AI Subtitle error", e);
    } {
      setIsGeneratingAISubtitles(false);
    }
  };

  // Launch voiceover recording simulation
  const startRecordingVoiceover = () => {
    setIsRecordingVoiceover(true);
    setVoiceoverTimer(0);
  };

  const stopRecordingVoiceover = () => {
    setIsRecordingVoiceover(false);
    // Create new audio track clip in Voicover Layer
    if (voiceoverTimer > 0) {
      const newVClip: TimelineClip = {
        id: `voiceover_${Date.now()}`,
        type: 'voiceover',
        title: `🔴 Voc_Session_${voiceoverTimer}s.wav`,
        start: Math.max(0, currentTime - voiceoverTimer),
        duration: voiceoverTimer,
        color: 'bg-amber-600/80 border-amber-400'
      };
      setTracks(prev => prev.map(track => {
        if (track.type === 'voiceover') {
          return {
            ...track,
            clips: [...track.clips, newVClip]
          };
        }
        return track;
      }));
    }
  };

  // Handle trimming/shifting clip boundaries manually
  const updateSelectedClipOffset = (field: 'start' | 'duration', value: number) => {
    if (!selectedClip) return;
    const boundedVal = Math.max(0, parseFloat((value).toFixed(1)));
    
    setTracks(prev => prev.map(track => {
      return {
        ...track,
        clips: track.clips.map(clip => {
          if (clip.id === selectedClip.id) {
            const updated = { ...clip, [field]: boundedVal };
            setSelectedClip(updated);
            return updated;
          }
          return clip;
        })
      };
    }));
  };

  // Split clip at current playhead position
  const handleSplitAtPlayhead = () => {
    if (!selectedClip) return;
    const splitTime = currentTime;
    if (splitTime <= selectedClip.start || splitTime >= (selectedClip.start + selectedClip.duration)) {
      alert("Please scrub the playhead red-line inside the selected clip to split it.");
      return;
    }

    const firstHalfDuration = parseFloat((splitTime - selectedClip.start).toFixed(1));
    const secondHalfDuration = parseFloat((selectedClip.duration - firstHalfDuration).toFixed(1));

    setTracks(prev => prev.map(track => {
      const remainingClips: TimelineClip[] = [];
      track.clips.forEach(clip => {
        if (clip.id === selectedClip.id) {
          remainingClips.push({
            ...clip,
            id: `${clip.id}_pt1`,
            title: `${clip.title} (A)`,
            duration: firstHalfDuration
          });
          remainingClips.push({
            ...clip,
            id: `${clip.id}_pt2`,
            title: `${clip.title} (B)`,
            start: splitTime,
            duration: secondHalfDuration
          });
        } else {
          remainingClips.push(clip);
        }
      });
      return { ...track, clips: remainingClips };
    }));
    setSelectedClip(null);
  };

  // Delete clip
  const deleteSelectedClip = () => {
    if (!selectedClip) return;
    setTracks(prev => prev.map(track => {
      return {
        ...track,
        clips: track.clips.filter(c => c.id !== selectedClip.id)
      };
    }));
    setSelectedClip(null);
  };

  // Speed ramping selection handler (effects clip properties)
  const applySpeedRampingPreset = (curve: string) => {
    setSpeedCurve(curve);
    if (selectedClip) {
      let speedMult = 1.0;
      if (curve === 'slow-mo') speedMult = 0.5;
      if (curve === 'fast') speedMult = 2.0;
      if (curve === 'hero') speedMult = 1.5; // Custom velocity curve

      setTracks(prev => prev.map(track => {
        return {
          ...track,
          clips: track.clips.map(clip => {
            if (clip.id === selectedClip.id) {
              const updated = { ...clip, speed: speedMult };
              setSelectedClip(updated);
              return updated;
            }
            return clip;
          })
        };
      }));
    }
  };

  // Apply visual cinematic filters
  const applyVisualFilter = (effectName: string) => {
    setSelectedEffect(effectName);
    if (selectedClip) {
      setTracks(prev => prev.map(track => {
        return {
          ...track,
          clips: track.clips.map(clip => {
            if (clip.id === selectedClip.id) {
              const updated = { ...clip, effect: effectName };
              setSelectedClip(updated);
              return updated;
            }
            return clip;
          })
        };
      }));
    }
  };

  // Purchase asset simulator
  const buyAssetPack = (packId: string, cost: number) => {
    if (premiumProActive) {
      setSoundPacks(prev => prev.map(p => p.id === packId ? { ...p, purchased: true } : p));
      return;
    }
    if (userCoins >= cost) {
      setUserCoins(prev => prev - cost);
      setSoundPacks(prev => prev.map(p => p.id === packId ? { ...p, purchased: true } : p));
    } else {
      alert("Not enough coins! Purchase a VibeCut Pro tier or unlock extra coins above.");
    }
  };

  // --- Main Mobile Video Export Execution ---
  const launchVideoExport = () => {
    setIsPlaying(false);
    
    // Check if configuration requires PRO
    if ((exportConfig.resolution === '4K' || exportConfig.fps === 60) && !premiumProActive) {
      setShowSubscriptionAlert(true);
      return;
    }

    // Trigger AdMob interstitial BEFORE export if free user
    if (!premiumProActive) {
      setAdTimer(5);
      setShowMockAd(true);
    } else {
      runActualExportProcess();
    }
  };

  // Ad mob interstitial countdown ticker
  useEffect(() => {
    let adInterval: any;
    if (showMockAd) {
      adInterval = setInterval(() => {
        setAdTimer((prev) => {
          if (prev <= 1) {
            clearInterval(adInterval);
            setShowMockAd(false);
            runActualExportProcess();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(adInterval);
  }, [showMockAd]);

  const runActualExportProcess = () => {
    setIsExporting(true);
    setExportProgress(0);
    setRenderOutputUrl(null);
    setExportLogs([
      "VibeCut High-Performance Mobile C++ FFmpeg Renderer Booting...",
      `Loading input clips from device storage:`,
      " - clip_1: Sunset Timelapse.mp4 [0s - 9s]",
      " - clip_2: Fast-Drive Cyberpunk.mp4 [9s - 20s]",
      `Injecting Audio track overlay Mix (Volume: 85%)`,
      "Analyzing Speed Ramping presets...",
    ]);

    let step = 0;
    const progressInterval = setInterval(() => {
      step += 10;
      setExportProgress(step);

      // Populate simulation native mobile ffmpeg compile terminal output
      if (step === 20) {
        setExportLogs(prev => [...prev, "Stitching multi-track assets into unified timescale.", "[Native C++] Resolving hardware H.264/AAC hardware encoders."]);
      } else if (step === 40) {
        setExportLogs(prev => [...prev, `GPU Pipeline: Scaling output buffers to fit aspect ratio ${exportConfig.aspectRatio}`, `Rendering frames at smooth ${exportConfig.fps} frames-per-second.`]);
      } else if (step === 65) {
        setExportLogs(prev => [...prev, "Burning-in rich vector subtitle fonts directly on video streams.", "[Speech-To-Text SDK] Audio extraction completed safely."]);
      } else if (step === 80) {
        setExportLogs(prev => [...prev, `Compressing streams (quality: ${exportConfig.bitrate === 'high' ? 'Ultra CRF 15' : 'CRF 21'})`, "Executing stitch-merge wrapper command... Done."]);
      } else if (step === 100) {
        clearInterval(progressInterval);
        setExportLogs(prev => [...prev, "🎉 Output compiled successfully! Saved to Camera Roll.", "Filename: VibeCut_Master_Export.mp4"]);
        
        // Setup output mockup URL
        if (exportConfig.aspectRatio === '9:16') {
          setRenderOutputUrl('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80');
        } else if (exportConfig.aspectRatio === '16:9') {
          setRenderOutputUrl('https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=1000&q=80');
        } else {
          setRenderOutputUrl('https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=600&q=80');
        }
      }
    }, 300);
  };

  // Helpers to check filters applied
  const getSimulatedFilterStyle = () => {
    const activeVClip = tracks.find(t => t.id === 't_effect')?.clips.find(clip => {
      return currentTime >= clip.start && currentTime <= (clip.start + clip.duration);
    });

    if (activeVClip?.effect === 'Glitch') {
      return 'hue-rotate-180 brightness-110 saturate-200 contrast-125 animate-pulse';
    }
    if (activeVClip?.effect === 'Cinematic') {
      return 'sepia saturate-150 hue-rotate-15 contrast-110 brightness-95';
    }
    return '';
  };

  const getSimulatedSubtitles = () => {
    const textTrack = tracks.find(t => t.id === 't_text');
    if (!textTrack) return '';
    const activeSub = textTrack.clips.find(clip => {
      return currentTime >= clip.start && currentTime <= (clip.start + clip.duration);
    });
    return activeSub ? activeSub.title : '';
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-100 flex flex-col selection:bg-rose-500 selection:text-white" id="main_root">
      
      {/* HEADER SECTION */}
      <header className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4 z-20 shadow-md">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-tr from-rose-600 to-purple-600 p-2.5 rounded-xl shadow-lg ring-2 ring-rose-500/30 flex-shrink-0">
            <Video className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display text-2xl font-extrabold tracking-tight bg-gradient-to-r from-rose-500 via-pink-400 to-purple-400 bg-clip-text text-transparent">VibeCut</span>
              <span className="font-mono text-[10px] tracking-widest bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-705 font-bold uppercase">Mobile Studio</span>
            </div>
            <p className="text-xs text-slate-400">FLUTTER / REACT NATIVE specifications & native multi-layer timeline simulator</p>
          </div>
        </div>

        {/* Free/Pro Header Status */}
        <div className="flex items-center gap-3 mt-1 md:mt-0 flex-wrap justify-center">
          <div className="bg-slate-800/80 px-4 py-2 rounded-xl border border-slate-700/60 flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5 font-mono text-slate-300">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>Coins: <strong className="text-amber-200">{userCoins}</strong></span>
              <button 
                onClick={() => setUserCoins(prev => prev + 50)} 
                className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 px-1.5 py-0.5 rounded text-[10px] ml-1.5 font-bold transition-all cursor-pointer"
                title="Add simulated developer coins for asset store test"
              >
                +50
              </button>
            </div>
            <div className="h-4 w-[1px] bg-slate-700" />
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Status:</span>
              {premiumProActive ? (
                <span className="bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-900 px-2.5 py-1 rounded-md text-[11px] font-bold shadow flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> PRO ACTIVE
                </span>
              ) : (
                <span className="bg-slate-700 text-slate-300 px-2.5 py-1 rounded-md text-[11px] font-medium">
                  FREE TIER
                </span>
              )}
            </div>
          </div>

          <button 
            onClick={() => {
              setPremiumProActive(prev => !prev);
              setShowSubscriptionAlert(false);
            }}
            className={`px-4 py-2 text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer ${
              premiumProActive 
                ? 'bg-slate-800 hover:bg-slate-700 border border-slate-750 text-slate-300' 
                : 'bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-600 hover:to-rose-700 text-white animate-pulse'
            }`}
          >
            {premiumProActive ? 'Change to Free Plan' : '⚡ Simulate Premium Pro'}
          </button>
        </div>
      </header>

      {/* CORE WORKSPACE SECTION */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: THE MOBILE PHONE EMULATOR (5 Cols) */}
        <section className="lg:col-span-5 flex flex-col gap-6" id="emulator_panel">
          
          {/* MOBILE PHONE CONTAINER */}
          <div className="bg-slate-900 rounded-[3rem] p-4 pt-10 pb-6 border-4 border-slate-800 shadow-2xl relative ring-2 ring-slate-850">
            {/* Speaker Grille & Camera Notch */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-32 h-5 bg-slate-950 rounded-full flex justify-between items-center px-4">
              <div className="w-12 h-1 bg-slate-800 rounded-full" />
              <div className="w-2 h-2 bg-slate-800 rounded-full" />
            </div>

            {/* Simulated Live Mobile Screen App Frame */}
            <div className="bg-slate-950 rounded-[2rem] overflow-hidden border border-slate-800 flex flex-col h-[520px] relative">
              
              {/* Emulator App Header */}
              <div className="bg-slate-905 py-3 px-4 border-b border-slate-800/60 flex justify-between items-center">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                  <span className="font-display text-[12px] font-bold text-white tracking-wide">VibeCut Live Stream</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-mono bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">Scrub: {currentTime.toFixed(1)}s</span>
                  {premiumProActive && <span className="text-amber-400 font-bold text-[10px]">👑 PRO</span>}
                </div>
              </div>

              {/* LIVE ACTIVE VIDEO PLAYBACK WORKSPACE */}
              <div className="flex-1 flex flex-col bg-slate-950 items-center justify-center p-3 relative select-none">
                
                {/* Outer Aspect Box wrapper */}
                <div 
                  className={`relative overflow-hidden bg-slate-900 rounded-xl shadow-inner border border-slate-800 transition-all duration-300 flex items-center justify-center ${
                    exportConfig.aspectRatio === '9:16' 
                      ? 'w-[190px] h-[330px]' 
                      : exportConfig.aspectRatio === '16:9' 
                        ? 'w-[320px] h-[180px]' 
                        : 'w-[240px] h-[240px]'
                  }`}
                >
                  
                  {/* Dynamic Backdrop Visual Stream Placeholder */}
                  <div className={`absolute inset-0 z-0 bg-slate-950 flex flex-col items-center justify-center`}>
                    <img 
                      src={
                        currentTime < 9 
                          ? 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80' // Sunset
                          : 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=600&q=80' // Cyberpunk
                      } 
                      alt="Visual channel streaming placeholder"
                      className={`w-full h-full object-cover transition-all duration-300 ${getSimulatedFilterStyle()}`}
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Simulated visual timeline details (overlaying graphics) */}
                    <div className="absolute inset-x-0 bottom-4 text-center px-2.5 z-10 select-none pointer-events-none drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                      <p className="text-[12px] font-bold font-display text-white tracking-wide bg-slate-900/90 py-1 px-2 rounded-md border border-white/10 break-words max-w-full inline-block">
                        {getSimulatedSubtitles()}
                      </p>
                    </div>

                    {/* Simulating running audio/sound waves visually */}
                    {isPlaying && tracks.some(t => t.id === 't_audio' && t.clips.length > 0) && (
                      <div className="absolute top-3 right-3 flex items-end gap-0.5 bg-black/40 px-2 py-1.5 rounded-md backdrop-blur-xs border border-white/5">
                        <span className="w-0.5 h-3 bg-emerald-400 animate-bounce" style={{ animationDelay: '0.1s' }} />
                        <span className="w-0.5 h-5 bg-emerald-400 animate-bounce" style={{ animationDelay: '0.3s' }} />
                        <span className="w-0.5 h-2 bg-emerald-400 animate-bounce" style={{ animationDelay: '0.2s' }} />
                        <span className="w-0.5 h-4 bg-emerald-400 animate-bounce" style={{ animationDelay: '0.4s' }} />
                      </div>
                    )}

                    {/* VibeCut Branding Watermark Overlay */}
                    {!premiumProActive && (
                      <div className="absolute top-3 left-3 bg-black/75 px-1.5 py-0.5 rounded text-[8px] font-bold text-slate-450 border border-slate-700 flex items-center gap-1 z-10">
                        <span>VibeCut Free</span>
                        <Lock className="w-2.5 h-2.5 text-rose-500" />
                      </div>
                    )}
                  </div>

                  {/* Absolute Filter Preview Name Display */}
                  <div className="absolute bottom-2 left-2 bg-slate-950/80 px-2 py-0.5 rounded text-[8px] text-slate-350 font-mono">
                    Filter: {selectedEffect}
                  </div>
                </div>

                {/* Simulated Wave synthesis timeline scrubber overlay (when recording voice) */}
                {isRecordingVoiceover && (
                  <div className="absolute inset-0 bg-slate-900/95 flex flex-col items-center justify-center p-6 text-center z-10 rounded-2xl border-4 border-rose-500/35">
                    <div className="w-12 h-12 rounded-full bg-rose-600 animate-ping absolute" />
                    <div className="w-12 h-12 rounded-full bg-rose-600 flex items-center justify-center relative z-10 ring-4 ring-rose-500/20">
                      <Mic className="w-5 h-5 text-white animate-bounce" />
                    </div>
                    <p className="mt-4 text-sm font-bold text-slate-100">Native Microphone Active</p>
                    <p className="text-xs text-rose-400 font-mono mt-1">Recording Segment: {voiceoverTimer}s</p>
                    <button 
                      onClick={stopRecordingVoiceover}
                      className="mt-4 px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer"
                    >
                      Save Audio Clip
                    </button>
                  </div>
                )}
              </div>

              {/* MONETIZATION: FIXED EMULATED AD BANNER AT BOTTOM */}
              {!premiumProActive && (
                <div className="bg-slate-900 border-t border-slate-800 p-2 text-center text-xs relative select-none">
                  <div className="absolute left-2 top-1.5 bg-amber-500 text-slate-950 px-1 py-0.2 rounded text-[7px] font-extrabold uppercase tracking-widest leading-none">
                    AdMob Ad
                  </div>
                  <div className="flex justify-center items-center gap-1.5 text-slate-400 py-1 font-mono text-[9px]">
                    <span className="text-rose-400">🔥 Upgrade to VibeCut Pro to disable watermarks & ads!</span>
                  </div>
                </div>
              )}

              {/* Emulator Screen Footer Controls */}
              <div className="bg-slate-900/95 border-t border-slate-800 p-3 flex justify-between items-center">
                <div className="flex gap-2">
                  <button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="p-2.5 rounded-lg bg-rose-600 text-white hover:bg-rose-500 transition-all cursor-pointer"
                    title={isPlaying ? "Pause Player" : "Play Player"}
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                  <button 
                    onClick={() => {
                      setIsPlaying(false);
                      setCurrentTime(0);
                    }}
                    className="px-3 py-2 text-xs bg-slate-800 text-slate-300 hover:bg-slate-750 rounded-lg transition-colors cursor-pointer"
                  >
                    Reset
                  </button>
                </div>
                <button
                  onClick={launchVideoExport}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow transition-all cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" /> Export Master
                </button>
              </div>

            </div>
          </div>

          {/* MONETIZATION: BILLING & PAYWALL PRO SIMULATOR */}
          <div className="bg-gradient-to-br from-slate-900 to-indigo-950 rounded-2xl p-5 border border-slate-800">
            <h3 className="font-display text-sm font-bold text-white flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" /> RevenueCat Paywall Integration
            </h3>
            <p className="text-xs text-slate-400 mt-1">Unlock raw 4K rendering capabilities, high FPS, full transition blocks and dismiss default Ads instantly.</p>
            
            <div className="grid grid-cols-3 gap-2 mt-4">
              {['weekly', 'monthly', 'yearly'].map((plan) => {
                const isSelected = selectedProPlan === plan;
                return (
                  <button 
                    key={plan}
                    onClick={() => setSelectedProPlan(plan as any)}
                    className={`p-3 rounded-lg border text-center transition-all cursor-pointer ${
                      isSelected 
                        ? 'border-indigo-505 bg-indigo-500/10 text-white ring-2 ring-indigo-500/20' 
                        : 'border-slate-800 bg-slate-950/60 text-slate-400'
                    }`}
                  >
                    <div className="text-[10px] uppercase text-indigo-400 font-bold">{plan}</div>
                    <div className="text-sm font-extrabold mt-1">
                      {plan === 'weekly' ? '$1.99' : plan === 'monthly' ? '$4.99' : '$29.99'}
                    </div>
                    <div className="text-[8px] text-zinc-550 leading-tight">
                      {plan === 'monthly' ? 'Best Value' : 'VibeCut Pro'}
                    </div>
                  </button>
                );
              })}
            </div>

            <button 
              onClick={() => {
                setPremiumProActive(true);
                setShowSubscriptionAlert(false);
                alert(`🎉 Subscription simulated successfully! High speed processing, watermarks removed, 4K rendering configured.`);
              }}
              className="w-full mt-4 bg-indigo-600 hover:bg-indigo-500 text-white py-2 rounded-xl text-xs font-bold transition-all shadow flex items-center justify-center gap-1 cursor-pointer"
            >
              <CheckCircle className="w-4 h-4" /> Subscribe with Mock Credit Card
            </button>
          </div>

          {/* ASSET STORE & VIRTUAL COIN MONETIZATION */}
          <div className="bg-slate-900 rounded-2xl p-5 border border-slate-800 flex flex-col gap-3">
            <h3 className="font-display text-sm font-bold text-white flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-rose-500" /> VibeCut Asset Micro-Store
            </h3>
            <p className="text-xs text-slate-400">Mock purchases of premium design fonts, transition packs, and high speed filters using coins.</p>
            
            <div className="flex flex-col gap-2 mt-2">
              {soundPacks.map((pack) => (
                <div key={pack.id} className="bg-slate-950 p-3 rounded-xl border border-slate-850 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-200 block">{pack.name}</span>
                    <span className="text-[10px] text-zinc-500 uppercase font-mono">{pack.type} block pack</span>
                  </div>
                  
                  {pack.purchased || premiumProActive ? (
                    <span className="text-emerald-400 font-bold bg-emerald-500/10 px-2 py-1 rounded text-[10px] flex items-center gap-1">
                      <Check className="w-3 h-3" /> Unlocked
                    </span>
                  ) : (
                    <button 
                      onClick={() => buyAssetPack(pack.id, pack.costInCoins)}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-extrabold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 cursor-pointer text-[11px]"
                    >
                      <Coins className="w-3 h-3 text-amber-500" /> {pack.costInCoins} Coins
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

        </section>

        {/* RIGHT COLUMN: TIMELINE WORKSPACE & DEVELOPER STUDIO (7 Cols) */}
        <section className="lg:col-span-7 flex flex-col gap-6" id="editor_workspace">
          
          {/* TIMELINE STUDIO CONTAINER */}
          <TimelineStudio 
            tracks={tracks}
            currentTime={currentTime}
            setCurrentTime={setCurrentTime}
            selectedClip={selectedClip}
            setSelectedClip={setSelectedClip}
            zoomFactor={zoomFactor}
            setZoomFactor={setZoomFactor}
            maxDuration={maxDuration}
            onSplit={handleSplitAtPlayhead}
            onDelete={deleteSelectedClip}
            onUpdateClipOffset={updateSelectedClipOffset}
            onApplySpeedPreset={applySpeedRampingPreset}
            onApplyVisualFilter={applyVisualFilter}
            speedCurve={speedCurve}
            isRecordingVoiceover={isRecordingVoiceover}
            startRecordingVoiceover={startRecordingVoiceover}
            stopRecordingVoiceover={stopRecordingVoiceover}
            aiPromptTopic={aiPromptTopic}
            setAiPromptTopic={setAiPromptTopic}
            isGeneratingAISubtitles={isGeneratingAISubtitles}
            handleAISubtitleGeneration={handleAISubtitleGeneration}
          />

          {/* COMPILATION ENGINE CONFIGURATIONS / MONETIZATION */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 shadow-xl flex flex-col gap-4">
            <h3 className="font-display text-sm font-bold text-white flex items-center gap-1.5">
              <Cpu className="w-4.5 h-4.5 text-emerald-400" /> FFmpeg Native Render Output Engine
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-850">
              {/* Aspect ratio */}
              <div>
                <label className="text-[10px] text-zinc-500 font-bold block mb-1">Aspect Ratio</label>
                <select 
                  value={exportConfig.aspectRatio}
                  onChange={(e) => setExportConfig(prev => ({ ...prev, aspectRatio: e.target.value as any }))}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white outline-none"
                >
                  <option value="9:16">9:16 (UI Portrait Reels)</option>
                  <option value="16:9">16:9 (Landscape YouTube)</option>
                  <option value="1:1">1:1 (Square Posts)</option>
                </select>
              </div>

              {/* Resolution options */}
              <div>
                <label className="text-[10px] text-zinc-500 font-bold block mb-1">Resolution Limit</label>
                <select 
                  value={exportConfig.resolution}
                  onChange={(e) => setExportConfig(prev => ({ ...prev, resolution: e.target.value as any }))}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white outline-none"
                >
                  <option value="720p">720p (Compressed HD)</option>
                  <option value="1080p">1080p (Standard Master)</option>
                  <option value="4K">4K Ultra HD 👑 PRO</option>
                </select>
              </div>

              {/* FPS options */}
              <div>
                <label className="text-[10px] text-zinc-550 font-bold block mb-1">Frames Per Second</label>
                <select 
                  value={exportConfig.fps}
                  onChange={(e) => setExportConfig(prev => ({ ...prev, fps: parseInt(e.target.value) as any }))}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white outline-none"
                >
                  <option value="30">30 fps (Standard Web)</option>
                  <option value="60">60 fps (Smooth Cinematic) 👑 PRO</option>
                </select>
              </div>

              {/* Bitrate options */}
              <div>
                <label className="text-[10px] text-zinc-550 font-bold block mb-1">Bitrate Allocation</label>
                <select 
                  value={exportConfig.bitrate}
                  onChange={(e) => setExportConfig(prev => ({ ...prev, bitrate: e.target.value as any }))}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white outline-none"
                >
                  <option value="standard">Standard (Average size)</option>
                  <option value="high">Ultra High Rendering bitrate</option>
                </select>
              </div>
            </div>

            {/* Run Export Terminal log simulation */}
            {isExporting && (
              <div className="bg-black text-rose-400 font-mono text-xs p-4 rounded-xl border border-slate-800 flex flex-col gap-2 max-h-56 overflow-y-auto">
                <div className="flex items-center justify-between border-b border-slate-900 pb-2">
                  <span className="text-zinc-400 uppercase tracking-widest text-[10px]">C++ compiling stream:</span>
                  <span className="text-emerald-400 font-bold">{exportProgress}% Completed</span>
                </div>
                <div className="flex flex-col gap-1 text-[11px] text-zinc-300">
                  {exportLogs.map((log, idx) => (
                    <div key={idx} className="leading-relaxed">
                      <span className="text-zinc-650 select-none mr-2">[{idx + 1}]</span>
                      {log}
                    </div>
                  ))}
                </div>
                {exportProgress < 100 && (
                  <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden mt-2">
                    <div className="bg-gradient-to-r from-rose-500 to-indigo-500 h-full transition-all duration-300" style={{ width: `${exportProgress}%` }} />
                  </div>
                )}
              </div>
            )}

            {/* Completed Output mockup view */}
            {renderOutputUrl && (
              <div className="bg-slate-950 p-4 rounded-xl border border-emerald-950 flex flex-col md:flex-row items-center gap-4 animate-fade-in shadow-xl">
                <div className="relative w-28 h-20 rounded border border-slate-8 w-full md:w-auto flex-shrink-0 bg-slate-900 overflow-hidden">
                  <img src={renderOutputUrl} alt="Export visual Master" className="w-full h-full object-cover select-none pointer-events-none" />
                </div>
                <div className="flex-1">
                  <span className="text-emerald-400 font-extrabold text-xs block uppercase tracking-widest mb-1">🎉 Video Compiled Successfully</span>
                  <p className="text-xs text-zinc-350">
                    Your export completed at <strong className="text-white">{exportConfig.resolution}</strong> with smooth <strong className="text-white">{exportConfig.fps}fps</strong>. Saved to native Camera Roll storage using high-speed mobile media encoders.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* SPECIFICATION CODE VIEWER - Flutter / React Native Native Specs (Mandatory) */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 shadow-xl flex flex-col gap-4" id="native_code_specs">
            <div className="flex justify-between items-center border-b border-slate-850 pb-3 flex-wrap gap-2">
              <div>
                <h3 className="font-display text-sm font-bold text-white flex items-center gap-2">
                  <Code className="w-4.5 h-4.5 text-rose-400" /> Flutter / Native C++ Flutter Architectures
                </h3>
                <p className="text-xs text-slate-400">Copy code specifications for BLoC timeline state, Native C++ FFmpeg compilation files, and Google AdMob paywall.</p>
              </div>
              <span className="text-[10px] text-zinc-550 font-mono">Production Ready</span>
            </div>

            {/* Tab switches */}
            <div className="flex gap-1 overflow-x-auto bg-slate-950 p-1.5 rounded-xl border border-slate-850 select-none">
              {codeSnippets.map((snippet) => (
                <button
                  key={snippet.path}
                  onClick={() => setActiveTabCode(snippet.path)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all whitespace-nowrap cursor-pointer ${
                    activeTabCode === snippet.path
                      ? 'bg-rose-500/10 text-rose-300 border border-rose-500/25'
                      : 'text-zinc-500 hover:text-slate-350 bg-transparent border border-transparent'
                  }`}
                >
                  {snippet.name}
                </button>
              ))}
            </div>

            {/* Code displaying board */}
            {codeSnippets.map((snippet) => {
              if (activeTabCode !== snippet.path) return null;
              return (
                <div key={snippet.path} className="flex flex-col gap-2 animate-fade-in">
                  <div className="flex justify-between items-center text-xs px-1 text-slate-450">
                    <span className="font-mono text-[10.5px]">Path: <strong className="text-slate-300">{snippet.path}</strong></span>
                    <span className="bg-slate-800 text-slate-300 font-mono text-[9px] uppercase px-1.5 py-0.5 rounded">{snippet.language}</span>
                  </div>
                  
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 overflow-x-auto max-h-80 select-all scrollbar-thin">
                    <pre className="text-[11px] font-mono text-zinc-300 leading-relaxed whitespace-pre font-medium">
                      {snippet.code}
                    </pre>
                  </div>
                </div>
              );
            })}
          </div>

        </section>

      </main>

      {/* --- MOCK ADMOB INTERSTITIAL POPUP OVERLAY --- */}
      {showMockAd && (
        <div className="fixed inset-0 bg-black/95 z-55 flex flex-col items-center justify-center p-6 text-center animate-fade-in select-none">
          <div className="bg-gradient-to-b from-slate-900 to-indigo-950 rounded-[2.5rem] border-4 border-slate-800 max-w-sm w-full p-6 pt-12 relative shadow-2xl">
            {/* Top Close count down */}
            <div className="absolute top-4 right-4 bg-black/50 text-[10px] px-3 py-1 rounded-full font-mono font-bold text-amber-400 border border-white/5">
              Ad closes in: {adTimer}s
            </div>

            <div className="w-16 h-16 bg-rose-600 rounded-3xl mx-auto flex items-center justify-center shadow-lg transform rotate-6 mb-6">
              <Sparkles className="w-8 h-8 text-white animate-pulse" />
            </div>

            <h3 className="font-display text-lg font-black text-white">VIBECUT PRO SPECIAL</h3>
            <p className="text-xs text-zinc-400 mt-2 px-4 leading-relaxed">
              Remove all watermarks, export in 4K resolution at high-speed 60fps, and download premium assets instantly!
            </p>

            {/* Ad Call To Action */}
            <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-850 mt-6 text-left">
              <span className="text-[9px] uppercase tracking-wider text-indigo-400 font-mono font-bold block mb-1">AdMob Sponsor</span>
              <span className="font-display font-black text-rose-400 text-sm block">VibeCut Pro Subscription</span>
              <span className="text-xs text-zinc-400 block mt-0.5">Start your 3-day free trial on RevenueCat.</span>
              
              <button 
                onClick={() => {
                  setPremiumProActive(true);
                  setShowMockAd(false);
                  alert("🎉 VibeCut Pro Activated! Commercial AdMob ads dismissed.");
                }} 
                className="w-full mt-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 rounded-xl text-xs transition-all shadow-md cursor-pointer"
              >
                Unlock Pro - $4.99/mo
              </button>
            </div>

            <p className="text-[10px] text-zinc-650 mt-4 leading-normal">
              Commercial interstitial ad mock triggering in free mode for export validation before rendering.
            </p>
          </div>
        </div>
      )}

      {/* --- MOCK PAYWALL SUBSCRIPTION ALERT FOR 4K EXPORTS --- */}
      {showSubscriptionAlert && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-sm w-full text-center">
            <div className="w-12 h-12 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-500 ring-4 ring-amber-500/5">
              <Lock className="w-6 h-6 animate-bounce" />
            </div>
            
            <h3 className="font-display text-md font-bold text-white">Upgrade to VibeCut Pro</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              4K high-FPS exports require an active VibeCut premium plan. Unlock 60fps and remove watermarks.
            </p>

            <button
              onClick={() => {
                setPremiumProActive(true);
                setShowSubscriptionAlert(false);
                alert("🎉 VibeCut Pro Activated!");
              }}
              className="w-full mt-4 bg-gradient-to-r from-amber-500 to-rose-600 hover:opacity-90 py-2 rounded-xl text-xs font-bold text-white shadow-lg transition-all cursor-pointer"
            >
              👑 Unlock 4K 60FPS Now
            </button>
            
            <button
              onClick={() => setShowSubscriptionAlert(false)}
              className="w-full mt-2 bg-slate-800 hover:bg-slate-750 py-2 rounded-xl text-xs text-slate-400 transition-all cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* FOOTER SECTION */}
      <footer className="bg-slate-900/60 border-t border-slate-800/80 px-6 py-4 mt-6 text-center text-xs text-slate-400 font-mono">
        <p>© 2026 VibeCut Mobile Workspace. Built with high performance Dart, C++ Native Code and React-Vite API server.</p>
      </footer>

    </div>
  );
}

// Icon fallbacks inside same module safely
function VideoIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m22 8-6 4 6 4V8Z" />
      <rect width="14" height="12" x="2" y="6" rx="2" ry="2" />
    </svg>
  );
}
