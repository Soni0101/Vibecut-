/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

function getFallbackSubtitles(topic: string, durationLimit: number) {
  const lowercaseTopic = (topic || '').toLowerCase();
  
  if (lowercaseTopic.includes('foldable') || lowercaseTopic.includes('tech') || lowercaseTopic.includes('review')) {
    return [
      { start: 0.5, end: 3.5, text: "Unboxing the brand new VibeFold Pro foldables! 📱" },
      { start: 3.8, end: 7.2, text: "The dynamic titanium hinge feels buttery smooth." },
      { start: 7.5, end: 11.0, text: "Let's overlay some glitch FX and record our uncompressed review." },
      { start: 11.5, end: 14.0, text: "Applying custom mobile speed curves: fast and slow-mo!" },
      { start: 14.2, end: 18.0, text: "Subscribe for more unboxings rendered in VibeCut Pro! 🔥" }
    ];
  } else if (lowercaseTopic.includes('travel') || lowercaseTopic.includes('neon') || lowercaseTopic.includes('vlog')) {
    return [
      { start: 1.0, end: 4.5, text: "Tokyo, Japan: Captured in ultra-crisp 4K resolution 🇯🇵" },
      { start: 4.8, end: 8.5, text: "The crosswalk is glowing with intense cyberpunk overlays..." },
      { start: 8.8, end: 12.2, text: "Ramping speed parameters: 5.0x speed -> 0.25x micro-ramping!" },
      { start: 12.5, end: 16.0, text: "Stitching these cinematic blocks onto our bottom timelines." },
      { start: 16.5, end: 19.5, text: "Where should we edit next? Comment below! ✈️" }
    ];
  } else {
    return [
      { start: 1.0, end: 4.0, text: "Welcome to VibeCut: AI Video Editor & Maker 🎬" },
      { start: 4.2, end: 7.8, text: "Experience the power of a native multi-layer timeline." },
      { start: 8.0, end: 11.5, text: "Apply high-fps speed-ramping, titles, and sound overlays." },
      { start: 12.0, end: 15.5, text: "Unlock Ad-Free Pro benefits for cinematic watermark-free video exports." },
      { start: 16.0, end: 19.0, text: "Crafted for maximum performance and touch precision!" }
    ];
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Safe lazy initializer for Gemini API client
  let aiInstance: GoogleGenAI | null = null;
  function getGeminiClient(): GoogleGenAI | null {
    if (!aiInstance) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
        return null;
      }
      aiInstance = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
    return aiInstance;
  }

  // API Endpoint: Dynamic Subtitle Studio generator using Gemini
  app.post('/api/generate-subtitles', async (req, res) => {
    const { topic = '', durationLimit = 20 } = req.body;
    const client = getGeminiClient();

    if (!client) {
      console.log("[VibeCut API Server] Gemini Client not active (no key). Supplying high-quality simulation subtitles.");
      return res.json({
        success: true,
        subtitles: getFallbackSubtitles(topic, durationLimit),
        mocked: true,
      });
    }

    try {
      const prompt = `You are the high-performance auto-subtitle engine of VibeCut mobile app.
Generate a chronological transcript of engaging video subtitle blocks based on this theme: "${topic}".
The video timeline is exactly ${durationLimit} seconds long.
Divide the timeline of ${durationLimit}s into 4-6 distinct, non-overlapping segments.
Each subtitle block MUST have precise times 'start' and 'end' in seconds, and subtitle 'text' for display.
All times must stay within 0.0 and ${durationLimit}.0 seconds.`;

      const response = await client.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              subtitles: {
                type: Type.ARRAY,
                description: "List of subtitle segments overlayed chronologically on the timeline",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    start: { type: Type.NUMBER, description: "Start timestamp in seconds" },
                    end: { type: Type.NUMBER, description: "End timestamp in seconds" },
                    text: { type: Type.STRING, description: "Subtitles/caption string with emojis" }
                  },
                  required: ['start', 'end', 'text']
                }
              }
            },
            required: ['subtitles']
          }
        }
      });

      const rawText = response.text || '{}';
      const parsed = JSON.parse(rawText);
      
      res.json({
        success: true,
        subtitles: parsed.subtitles || getFallbackSubtitles(topic, durationLimit),
        mocked: false,
      });
    } catch (err: any) {
      console.error("[VibeCut API Server] Error calling Gemini API:", err);
      res.json({
        success: true,
        subtitles: getFallbackSubtitles(topic, durationLimit),
        mocked: true,
        error: err.message || 'Gemini response error'
      });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Vite Integration & Page Loading Middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[VibeCut Server] Full-stack studio running on http://localhost:${PORT}`);
  });
}

startServer();
